1. run prepare_data.py to prepare training data
2. run construct_validation_data.py to construct validation data
3. run data_loader.py to train the model
4. run test_accuracy.py to find the best threshold



'Best F:', 0.9267233400826453, 'Best threshold: ', 8.082808730602265



