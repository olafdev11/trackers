# code path
base_path = '/home/zj/tracking/VOT2022/submit/VITKT_M/vitkt_m'
