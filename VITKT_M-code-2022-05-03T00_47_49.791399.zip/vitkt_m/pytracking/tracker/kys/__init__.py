from .kys import KYS


def get_tracker_class():
    return KYS