from .admin.multigpu import MultiGPU
