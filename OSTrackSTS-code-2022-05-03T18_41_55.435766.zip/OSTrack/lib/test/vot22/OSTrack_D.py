import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))

from lib.test.vot22.d_tracker import run_vot_exp

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
run_vot_exp('ostrack_online', 'depth320_64x2_ep50', vis=False)
