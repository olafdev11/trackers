import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))

from lib.test.vot22.stb_tracker import run_vot_exp

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
run_vot_exp('ostrack_online', 'ostrack320_elimination_cls_t2m3_ep50', vis=False)
