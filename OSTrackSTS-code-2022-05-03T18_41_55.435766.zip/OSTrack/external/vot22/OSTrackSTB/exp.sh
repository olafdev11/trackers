vot evaluate --workspace . OSTrackSTB
vot analysis --workspace . OSTrackSTB --format html
