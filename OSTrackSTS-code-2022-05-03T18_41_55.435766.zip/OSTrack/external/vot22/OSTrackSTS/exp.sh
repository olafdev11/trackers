vot evaluate --workspace . OSTrackSTS
vot analysis --workspace . OSTrackSTS --format html
