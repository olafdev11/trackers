vot evaluate --workspace . OSTrack_D
vot analysis --workspace . OSTrack_D --format html
