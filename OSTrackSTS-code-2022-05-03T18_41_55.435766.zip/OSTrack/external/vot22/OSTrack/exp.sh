vot evaluate --workspace . OSTrack
vot analysis --workspace . OSTrack --format html
