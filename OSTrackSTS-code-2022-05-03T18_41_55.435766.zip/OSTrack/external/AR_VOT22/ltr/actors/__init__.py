from .base_actor import BaseActor

'''VOT2020'''
from .ARcm import ARcm_Actor
from .ARmask import ARmask_Actor
from .ARcm_dtm import ARcm_dtm_Actor
