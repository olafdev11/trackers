# Dependency Preparation
```
sudo apt-get install libturbojpeg0

# install libGL.so.1
sudo apt update
sudo apt install libgl1-mesa-glx

# install gcc&g++ 7.5.0
sudo apt-get update
sudo apt-get install gcc-7
sudo apt-get install g++-7

sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-7 100
sudo update-alternatives --config gcc

sudo update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-7 100
sudo update-alternatives --config g++

# install ninja-build for Precise ROI pooling
sudo apt-get install ninja-build
```


# Singularity Version 

## Hardware Requirements
* GPU: GeForce RTX 3090 (24 GB memory)
* CPU: Intel(R) Xeon(R) Silver 4210R CPU @ 2.40GHz 
* Memory: 190 GB
* HD: 879 GB

# Run MS-AOT

* Use `singularity pull` to build image that we made
```
singularity pull --arch amd64 library://qiangming/ms_aot/ms_aot:latest
```

* Run ms_aot_latest.sif
```
singularity shell --nv ms_aot_latest.sif
```

* Run the following command to set paths for this MixFormer
```
cd MS_AOT/MixFormer
python tracking/create_default_local_file.py --workspace_dir . --data_dir ./data --save_dir .
```

* Download the checkpoint of [MS-AOT](https://drive.google.com/file/d/1aEvMAcx3sJ2FRBIb0MsCSsvJrp3M0Cce/view?usp=sharing), and move it into `MS_AOT/pretrain_models`:
```
mv ms_aot_model.pth MS_AOT/pretrain_models
```
* Download the checkpoint of [MixFormer](https://drive.google.com/file/d/18qfUTVOyQ7Nyz8QaEoa2zecVbQCnbtWV/view?usp=sharing), and move it into `MS_AOT/MixFormer/models`:
  
```
mv mixformerL_online_22k.pth.tar MS_AOT/MixFormer/models
```

* Use vot-toolkit-python to initialize the workspace 
```
vot initialize <stack-name> --workspace <workspace-path>
```

* Modify the `"paths"` and `"env_PATH"` in the `trackers.ini` regarding your environment

* To get results, use `vot-toolkit` 
```
vot evaluate --workspace $(pwd) MS_AOT
```
* or use our script
```
chmod +x evaluate_ms_aot.sh
./evaluate_ms_aot.sh
```

**Note: We recommend to use evaluate_ms_aot.sh to get results, since the vot toolkit will sometimes be interrupted due to the slow building of models. Before run `evaluate_ms_aot.sh`, you should modify the `workspace` defined in it.**





================================================================================




# Conda Version
# Requirements

## Hardware Requirements
* GPU: GeForce RTX 3090 (24 GB memory)
* CPU: Intel(R) Xeon(R) Silver 4210R CPU @ 2.40GHz 
* Memory: 190 GB
* HD: 879 GB

## Software Dependency
* OS: Ubuntu 18.04.6 LTS
* Anaconda 3
* CUDA 11.2
* Python 3.7.13, Pytorch 1.10.1, torchvision=0.11.2 and more...
* gcc 7.5.0 , g++ 7.5.0


## A quick way to install all dependency packages
* Download the conda environment package from [MS_AOT_ENVIRONMENT](https://drive.google.com/file/d/13KZoqi36zm594POrJtW7DkZ7VT8HX1rP/view?usp=sharing), 
  then, execute:
```
tar -zxvf ms_aot.tar.gz
```

* **Copy the directory `ms_aot` to `/path/to/anaconda3/envs/` and activate the environment.**
```
cp -r ms_aot /path/to/anaconda3/envs/ 
conda activate ms_aot
```

## A normal way
```
conda env create -f environment.yml
```

# Run MS_AOT

* Run the following command to set paths for this project
```
cd MS_AOT/MixFormer
python tracking/create_default_local_file.py --workspace_dir . --data_dir ./data --save_dir .
```
* After running this command, you can also modify paths by editing these two files
```
lib/train/admin/local.py  # paths about training
lib/test/evaluation/local.py  # paths about testing
```

* Download the checkpoint of [MS-AOT](https://drive.google.com/file/d/1aEvMAcx3sJ2FRBIb0MsCSsvJrp3M0Cce/view?usp=sharing), and move it into `MS_AOT/pretrain_models`:
```
mv ms_aot_model.pth MS_AOT/pretrain_models
```
* Download the checkpoint of [Mixformer](https://drive.google.com/file/d/18qfUTVOyQ7Nyz8QaEoa2zecVbQCnbtWV/view?usp=sharing), and move it into `MS_AOT/MixFormer/models`:
  
```
mv mixformerL_online_22k.pth.tar MS_AOT/MixFormer/models
```

* Use vot-toolkit-python to initialize the workspace 
```
vot initialize <stack-name> --workspace <workspace-path>
```

* Modify the "paths" and "env_PATH" in the trackers.ini regarding your environment

* To get results, use `vot-toolkit` 
```
vot evaluate --workspace $(pwd) MS_AOT
```
* or use our script
```
chmod +x evaluate_ms_aot.sh
./evaluate_ms_aot.sh
```

**Note: We recommend to use evaluate_ms_aot.sh to get results, since the vot toolkit will sometimes be interrupted due to the slow building of models. Before run `evaluate_ms_aot.sh`, you should modify the `workspace` defined in it.**


# Contact
If you have any problems about the environment settings and result reproduction, feel free to email 22151080@zju.edu.cn and we will reply as soon as possible ^_^
