#! /bin/bash

for i in {1..20}
do
    CUDA_VISIBLE_DEVICES=2 vot evaluate --workspace /home/supermicr/temp MS_AOT
done

vot analysis --workspace /home/supermicr/temp MS_AOT