from lib.test.evaluation.environment import EnvSettings

def local_env_settings():
    settings = EnvSettings()

    # Set your local paths here.

    settings.davis_dir = ''
    settings.got10k_lmdb_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/got10k_lmdb'
    settings.got10k_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/got10k'
    settings.got_packed_results_path = ''
    settings.got_reports_path = ''
    settings.lasot_lmdb_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/lasot_lmdb'
    settings.lasot_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/lasot'
    settings.network_path = '/home/lz/PycharmProjects/MixFormer_RGBD/test/networks'    # Where tracking networks are stored.
    settings.nfs_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/nfs'
    settings.otb_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/OTB2015'
    settings.prj_dir = '/home/lz/PycharmProjects/MixFormer_RGBD'
    settings.result_plot_path = '/home/lz/PycharmProjects/MixFormer_RGBD/test/result_plots'
    settings.results_path = '/home/lz/PycharmProjects/MixFormer_RGBD/test/tracking_results'    # Where to store tracking results
    settings.save_dir = '/home/lz/PycharmProjects/MixFormer_RGBD'
    settings.segmentation_path = '/home/lz/PycharmProjects/MixFormer_RGBD/test/segmentation_results'
    settings.tc128_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/TC128'
    settings.tn_packed_results_path = ''
    settings.tpl_path = ''
    settings.trackingnet_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/trackingNet'
    settings.uav_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/UAV123'
    settings.vot_path = '/home/lz/PycharmProjects/MixFormer_RGBD/data/VOT2019'
    settings.youtubevos_dir = ''

    return settings

