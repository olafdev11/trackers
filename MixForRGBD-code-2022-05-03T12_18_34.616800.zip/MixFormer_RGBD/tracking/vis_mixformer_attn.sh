python tracking/test.py mixformer_online baseline --dataset lasot --sequence 'car-2' --threads 1 --num_gpus 1 --params__model mixformer_online_22k.pth.tar --params__search_area_scale 4.55 \
    --params__online_sizes 1 --params__vis_attn 1

