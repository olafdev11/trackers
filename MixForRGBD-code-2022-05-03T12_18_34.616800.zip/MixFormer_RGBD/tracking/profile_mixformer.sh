# MixFormer
python tracking/profile_model.py --script mixformer_online --config baseline --online_skip 200 --display_name 'Mixformer'

# MixFormer-L
python tracking/profile_model.py --script mixformer_online --config baseline_large --online_skip 200 --display_name 'Mixformer-L'